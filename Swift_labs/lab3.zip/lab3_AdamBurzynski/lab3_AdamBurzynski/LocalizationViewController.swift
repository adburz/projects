//
//  LocalizationViewController.swift
//  lab3_AdamBurzynski
//
//  Created by Student on 05/12/2020.
//  Copyright © 2020 polsl. All rights reserved.
//

import UIKit
import CoreLocation

class LocalizationViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longtitudeLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    
    let locationManager = CLLocationManager()
    var location: CLLocation?
    
    let geocoder = CLGeocoder()
    var placemark: CLPlacemark?
    var performingReverseGeocoding = false
    var lastGeocodingError: Error?
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        if(error as NSError).code == CLError.locationUnknown.rawValue{return}
        
        print("Failed to find user's location: \(error.localizedDescription)")
        locationManager.stopUpdatingLocation()
        locationManager.delegate = nil
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        
        let newLocation = locations.last!
        location = newLocation
        if let location = location{
            latitudeLabel.text = String(format: "%.8f", location.coordinate.latitude)
            longtitudeLabel.text = String(format: "%.8f", location.coordinate.longitude)
            
        }
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func showLocationServicesDeniedAlert(){
        let alert = UIAlertController(title: "Location Services Disabled!", message: "Please enable location services for this app in Settings.", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        
        alert.addAction(okAction)
        present(alert,animated: true, completion: nil)
    }
    @IBAction func getLocalizationbutton_Click(_ sender: Any) {
        let authStatus:CLAuthorizationStatus = CLLocationManager.authorizationStatus()
        if authStatus == .notDetermined{
           locationManager.requestWhenInUseAuthorization()
            return
        }else if authStatus == .denied || authStatus == .restricted{
            showLocationServicesDeniedAlert()
        }
        else{
locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
    }
    
    func locationName (from placemark: CLPlacemark) -> String{
        return "\(placemark.locality ?? "") \(placemark.administrativeArea ?? "")\n" + "\(placemark.thoroughfare ?? "") \(placemark.subThoroughfare ?? "")\n" + "\(placemark.postalCode ?? "")"
    }
    
    @IBAction func getAddressButton_Click(_ sender: Any) {
        if !performingReverseGeocoding{
            performingReverseGeocoding = true
            
            geocoder.reverseGeocodeLocation(location!, completionHandler: {placemarks, error in print("Found place: \(String(describing: placemarks)), error: \(String(describing: error))")
                if error == nil, let p = placemarks, !p.isEmpty{
                self.placemark = p.last!
                self.addressLabel.text = self.locationName(from:self.placemark!)
                self.performingReverseGeocoding = false
            }else{
                self.placemark = nil
            }
        })
    
    
    }
    
    

    
}
}
