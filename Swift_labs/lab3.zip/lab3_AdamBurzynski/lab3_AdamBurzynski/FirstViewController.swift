//
//  FirstViewController.swift
//  lab3_AdamBurzynski
//
//  Created by Student on 05/12/2020.
//  Copyright © 2020 polsl. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UIGestureRecognizerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer ) -> Bool {
        return true
    }
    
    @IBAction func handlePan(_ recognizer:UIPanGestureRecognizer){
        let translation = recognizer.translation(in: self.view)
        
        if let view = recognizer.view{
            view.center = CGPoint(x:view.center.x + translation.x,
                                  y:view.center.y + translation.y)}
        
        recognizer.setTranslation(CGPoint.zero, in: self.view)
        }
    
    @IBAction func handleRotate(_ sender: UIRotationGestureRecognizer) {
        
        sender.view!.transform = sender.view!.transform.rotated(by: sender.rotation)
        
        sender.rotation = 0
        
        
    }
    
    @IBAction func handlePinch(_ sender: UIPinchGestureRecognizer) {
        
        sender.view!.transform = (sender.view!.transform.scaledBy(x: sender.scale, y: sender.scale))
        
        sender.scale = 1.0
    }
}
