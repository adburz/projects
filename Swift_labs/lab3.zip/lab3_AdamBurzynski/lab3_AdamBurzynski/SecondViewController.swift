//
//  SecondViewController.swift
//  lab3_AdamBurzynski
//
//  Created by Student on 05/12/2020.
//  Copyright © 2020 polsl. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet var doubleTapRecognizer: UITapGestureRecognizer!
    @IBOutlet var swipeRecognizer: UISwipeGestureRecognizer!
    @IBOutlet var singleTapRecognizer: UITapGestureRecognizer!
    
    var timer = Timer()
    var time = 0

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        swipeRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        
        singleTapRecognizer=UITapGestureRecognizer(target: self, action: #selector(handleSingleTap(_:)))
        
        doubleTapRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        swipeRecognizer.direction = .right
        swipeRecognizer.numberOfTouchesRequired = 1
        
        
        view.addGestureRecognizer(swipeRecognizer)
        view.addGestureRecognizer(singleTapRecognizer)
        view.addGestureRecognizer(doubleTapRecognizer)
    }

    @IBAction func updateTimeLabel(_ sender: Timer){
        time+=1
        countLabel.text = String(time)
    }
    
    @IBAction func handleSwipe(_ sender: UISwipeGestureRecognizer) {
        time = 0
        countLabel.text = String(time)
    }
    
    @IBAction func handleSingleTap(_ sender: UITapGestureRecognizer) {
        startTimer()
    }
    
    @IBAction func handleDoubleTap(_ sender: UITapGestureRecognizer) {
        stopTimer()
    }
    
    func stopTimer(){
        if timer.isValid == true{
        timer.invalidate()
        }
    }
    
    func startTimer(){
        if timer.isValid == false{
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimeLabel(_:)), userInfo: nil, repeats: true)
        }
    }
    
    
    
}
