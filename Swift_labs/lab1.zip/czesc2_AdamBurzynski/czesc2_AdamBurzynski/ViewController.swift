//
//  ViewController.swift
//  czesc2_AdamBurzynski
//
//  Created by Student on 07/11/2020.
//  Copyright © 2020 Flis. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var wartoscLosowa = 0
    var current_points = 0
    var roundCount = 1
    
    func losuj()
    {
        wartoscLosowa = Int.random(in: 1...100)
        wylosowana.text = String(wartoscLosowa)
    }
    
    func aktualizuj_rundy_i_punkty()
    {
        show_points.text = String(current_points)
        rounds.text = String(roundCount)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        losuj()
        aktualizuj_rundy_i_punkty()
    }
    @IBOutlet weak var rounds :UILabel!
    @IBOutlet weak var slider:UISlider!
    @IBOutlet weak var wylosowana: UILabel!
    @IBOutlet weak var show_points: UILabel!
    
    func restart()
    {
        current_points = 0
        roundCount = 1
        aktualizuj_rundy_i_punkty()
        
    }
    
    @IBAction func restartButton_click(_ sender: UIButton) {
        restart()
    }
    
    @IBAction func obslugaSprawdz()
    {
        var punkty = 100
        var tmp = 0
        if wartoscLosowa > Int(slider.value)
        {
           tmp = wartoscLosowa - Int(slider.value)
            
        }
        else
        {
            tmp = Int(slider.value) - wartoscLosowa
        }
        
        print("\(wartoscLosowa)")
        print("\(Int(slider.value))")
        print("\(tmp)")
        punkty -= tmp
        
        current_points += punkty
        
        roundCount+=1
        
        aktualizuj_rundy_i_punkty()
        
        
        
        if roundCount > 10
        {
            
            let alert = UIAlertController(title: "Gra skonczona!", message: "Udalo Ci sie zdobyc \(punkty), a w sumie \(current_points) punktow", preferredStyle: .alert)
            let action = UIAlertAction(title:"Ok", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
            restart()
            losuj()
        }
        else
        {
            let alert = UIAlertController(title: "Punkty", message: "\(punkty)", preferredStyle: .alert)
            let action = UIAlertAction(title:"Graj", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
            losuj()
        }
    

}

}
