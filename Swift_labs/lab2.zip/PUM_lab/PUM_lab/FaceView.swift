//
//  FaceView.swift
//
//  Created by Lab PUM on 30.09.2018.
//  Copyright © 2018 MM. All rights reserved.
//

import UIKit

class FaceView: UIView {

    var ctrlPoint = CGPoint(x: 0.0, y: 217) //hardcoded value for straight mouth line
    var _red:CGFloat = 0.5
    var _blue:CGFloat = 0.5
    var _green:CGFloat = 0.5
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        let bounds:CGRect = self.bounds
        
        var midPoint=CGPoint() // center of our bounds in our coordinate system
        midPoint.x = bounds.origin.x + bounds.size.width/2
        midPoint.y = bounds.origin.y + bounds.size.height/2
        
     
        var point1=CGPoint()
        point1.x = midPoint.x
        point1.y = midPoint.y
        
        //HEAD
        let path:UIBezierPath=UIBezierPath()
        path.addArc(withCenter: point1, radius: 110, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        path.lineWidth=10
        let color = UIColor(red: _red, green: _green, blue: _blue, alpha: alpha)
        color.setFill()
        path.stroke()
        path.fill()

        
        
        //LEFT EYE
        var point2=CGPoint()
        point2.x = midPoint.x - 40
        point2.y = midPoint.y - 30
        
        let path2:UIBezierPath=UIBezierPath()
        path2.addArc(withCenter: point2, radius: 15, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        UIColor.white.setFill()
        path2.lineWidth=10
        path2.stroke()
        path2.fill()
        
        //RIGHT EYE
        var point3=CGPoint()
        point3.x = midPoint.x + 40
        point3.y = midPoint.y - 30
        let path3:UIBezierPath=UIBezierPath()
        path3.addArc(withCenter: point3, radius: 15, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        UIColor.white.setFill()
        path3.lineWidth=10
        path3.stroke()
        path3.fill()
        
        
        //MOUTH
        var startPoint = CGPoint()
        startPoint.x = midPoint.x - 40
        startPoint.y = midPoint.y + 60
        var endPoint = CGPoint()
        endPoint.x = midPoint.x + 40
        endPoint.y = midPoint.y + 60
        
        ctrlPoint.x = midPoint.x
        
        let smile:UIBezierPath = UIBezierPath()
        
        smile.move(to: startPoint)
        smile.addQuadCurve(to: endPoint, controlPoint: ctrlPoint)
        smile.lineWidth=5
        smile.stroke()
  
    }
    

}
