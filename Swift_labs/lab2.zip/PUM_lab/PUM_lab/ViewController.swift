//
//  ViewController.swift
//
//  Created by Lab PUM on 30.09.2018.
//  Copyright © 2018 MM. All rights reserved.
//

import UIKit

class ViewController: UIViewController, myDelegateProtocol {
    
    @IBOutlet weak var face: FaceView!
    
    
    func myDelegateFunction(happiness: Float) {
        face.ctrlPoint.y = CGFloat(happiness) + 217
        face.setNeedsDisplay()
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        face.setNeedsDisplay()
        // Do any additional setup after loading the view, typically from a nib.
    }
    //unwind segue
    @IBAction func smile_exit (_ segue:UIStoryboardSegue){
    }
    //unwind segue
    @IBAction func color_exit (_ segue:UIStoryboardSegue){
        
        let colorSource = segue.source as! ColorViewController
        
        face._blue = CGFloat(colorSource.blueSlider.value)
        face._red = CGFloat(colorSource.redSlider.value)
        face._green = CGFloat(colorSource.greenSlider.value)

        face.setNeedsDisplay()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "setColorSegue"{
            let destination = segue.destination as! ColorViewController
            destination.blue = Float(face._blue)
            destination.red = Float(face._red)
            destination.green = Float(face._green)
        }
        else if segue.identifier == "setSmileSegue"{
            let destination = segue.destination as! SmileViewController
            destination.delegate = self
            destination.happiness = (Float(face.ctrlPoint.y) - 217)
        }
        
    }}

