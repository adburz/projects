//
//  SmileViewController.swift
//  PUM_lab
//
//  Created by Student on 01/12/2020.
//  Copyright © 2020 PS. All rights reserved.
//

import UIKit

protocol myDelegateProtocol:class{
    
    func myDelegateFunction(happiness:Float)
}

class SmileViewController: UIViewController {

    var happiness:Float = 0.0
    
    @IBOutlet weak var happinessSlider: UISlider!
    
    weak var delegate : myDelegateProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        happinessSlider.value = happiness
        // Do any additional setup after loading the view.
    }
    
    @IBAction func exit(_ sender: Any) {
        
        delegate?.myDelegateFunction(happiness: happinessSlider.value)
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
