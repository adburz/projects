//
//  ColorViewController.swift
//  PUM_lab
//
//  Created by Student on 01/12/2020.
//  Copyright © 2020 PS. All rights reserved.
//

import UIKit

class ColorViewController: UIViewController {
    
    var red:Float = 0.5
    var blue:Float = 0.5
    var green:Float = 0.5
    
    @IBOutlet weak var redSlider: UISlider!
    
    @IBOutlet weak var greenSlider: UISlider!
    
    @IBOutlet weak var blueSlider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        redSlider.value = red
        greenSlider.value = green
        blueSlider.value = blue
        //Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
